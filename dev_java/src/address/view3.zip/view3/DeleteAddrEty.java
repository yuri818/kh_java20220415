package address.view3;

public class DeleteAddrEty {

	public AddressVO delete(AddressVO vo) {
		System.out.println("DeleteAddrEty delete 호출 성공");
		return null;
	}

}
