package address.view3;

public class ModifyAddrEty {

	public AddressVO modify(AddressVO vo) {
		System.out.println("ModifyAddrEty modify 호출 성공");
		return null;
	}

}
