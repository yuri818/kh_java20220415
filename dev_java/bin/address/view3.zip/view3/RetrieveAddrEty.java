package address.view3;

import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Vector;

// 이 클래스가 select역할을 담당한다

public class RetrieveAddrEty {
	// 이른 인스턴스화(<-> 게으른 인스턴스화)
	DBConnectionMgr 	dbMgr 	= new DBConnectionMgr();
	Connection 			con 	= null;
	PreparedStatement 	pstmt 	= null;
	ResultSet 			rs 		= null;
	
	/***************************************************************************
	 * 회원정보 중 상세보기 구현 - 1건 조회
	 * SELECT id, name, address, DECODE(gender,'1','남','여') as "성별"
            , relationship, comments, registedate, birthday
         FROM mkaddrtb
        WHERE id = 5
	 * @param vo : 사용자가 선택한 값
	 * @return AddressVO : 조회 결과 1건을 담음
	 **************************************************************************/
	public AddressVO retrieve(AddressVO vo) {
		System.out.println("RetrieveAddrEty retrieve(AddressVO vo) 호출 성공");
		AddressVO rVO = null;
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT id, name, address, telephone, gender				  ");
	    sql.append("  	  ,relationship, birthday, comments, registedate      ");
	    sql.append("  FROM mkaddrtb                                           ");
	    sql.append(" WHERE id = ?											  ");
	    // AddressBook에서 선택한 로우의 id값 담기
	    int id = vo.getId();
	    try {
	    	con 	= dbMgr.getConnection();
			pstmt 	= con.prepareStatement(sql.toString());
			pstmt.setInt(1, id);
			rs 		= pstmt.executeQuery();
			if(rs.next()) {
				// 게으른 인스턴스화
				rVO = new AddressVO();
//				rVO.setName(rs.getString(2)); // 이렇게 하지마라~~ 컬럼명 적어주세요. 숫자로하면 모름
				rVO.setName(rs.getString("name"));
				rVO.setAddress(rs.getString("address"));
				rVO.setTelephone(rs.getString("telephone"));
				rVO.setGender(rs.getString("gender"));
				rVO.setRelationship(rs.getString("relationship"));
				rVO.setBirthday(rs.getString("birthday"));
				rVO.setComments(rs.getString("comments"));
				rVO.setRegistedate(rs.getString("registedate"));
				// 잌 노드를 쓰지 않는자와 쓰는자 그 차이 - 한끝차이
				rVO.setId(rs.getInt("id"));
				// 상세보기에서는 id가 필요 없지만 수정처리할 때는 id가 필요하니까 넣어두자
				// UPDATE mkaddrtb set address = "서울시 강남구 역삼동" WHERE id =? 
			}
		} catch (SQLException se) {
			System.out.println("[[query]]" + sql.toString());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbMgr.freeConnection(rs, pstmt, con);
		}
//	    return null; - 배달사고
		return rVO;
	}
	/***************************************************************************
	 * 회원 목록 보기 구현 - n건 조회
	 * SELECT id, name, address, DECODE(gender,'1','남','여') as "성별"
            , relationship, comments, registedate, birthday
         FROM mkaddrtb
	 * @param vo : 사용자가 선택한 값
	 * @return AddressVO : 조회 결과 1건을 담음
	 **************************************************************************/
	public AddressVO[] retrieve() {
		System.out.println("RetrieveAddrEty retrieve() 호출 성공");
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT id, name, address, telephone, gender				  ");
	    sql.append("  	  ,relationship, birthday, comments, registedate      ");
	    sql.append("  FROM mkaddrtb                                           ");
	    AddressVO[] vos = null;
	    try {
			con 	= dbMgr.getConnection();
			pstmt 	= con.prepareStatement(sql.toString());
			rs 		= pstmt.executeQuery();
			Vector<AddressVO> v = new Vector<>();
			// 화면에 나갈 VO
			AddressVO rVO = null;
			while(rs.next()) {
				rVO = new AddressVO(rs.getString("name")
								   ,rs.getString("address")
								   ,rs.getString("telephone")
								   ,rs.getString("gender")
								   ,rs.getString("relationship")
								   ,rs.getString("birthday")
								   ,rs.getString("comments")
								   ,rs.getString("registedate")
								   ,rs.getInt("id")
									);
				v.add(rVO); //v.size() -> 배열의 크기 결정해야함
			}
			vos = new AddressVO[v.size()];
			v.copyInto(vos); // 배열의 값을 복사해준다 - 이 메소드 쓰려고 굳이 벡터 쓴거얌
		} catch (SQLException se) {
			System.out.println("[[query]]" + sql.toString());
		} catch(Exception e) {
			e.printStackTrace(); // 에러 스택에 쌓여 있는 로그 정보 출력해줌. 라인번호도 같인
		} finally {
			// DB연동해서 사용한 자원 반납하기 - 노출가능, 우변조
			dbMgr.freeConnection(rs, pstmt, con);
		}
		return vos;
	}
	// MyBatis때문에 추가한 부분 //
	public List<Map<String,Object>> myBatisretrieve() {
		System.out.println("RetrieveAddrEty retrieve() 호출 성공");
		// 물리적으로 위치해있는 곳 알기 위해서
		String resource = "address/view3/MaperConfig.xml";
		// xml에 쿼리문있어서 필요없다 - reader는 2byte단위로 처리하는 클래스
		Reader reader = null;
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT id, name, address, telephone, gender				  ");
	    sql.append("  	  ,relationship, birthday, comments, registedate      ");
	    sql.append("  FROM mkaddrtb                                           ");
	    AddressVO[] vos = null;
	    try {
			con 	= dbMgr.getConnection();
			pstmt 	= con.prepareStatement(sql.toString());
			rs 		= pstmt.executeQuery();
			Vector<AddressVO> v = new Vector<>();
			// 화면에 나갈 VO
			AddressVO rVO = null;
			while(rs.next()) {
				rVO = new AddressVO(rs.getString("name")
								   ,rs.getString("address")
								   ,rs.getString("telephone")
								   ,rs.getString("gender")
								   ,rs.getString("relationship")
								   ,rs.getString("birthday")
								   ,rs.getString("comments")
								   ,rs.getString("registedate")
								   ,rs.getInt("id")
									);
				v.add(rVO); //v.size() -> 배열의 크기 결정해야함
			}
			vos = new AddressVO[v.size()];
			v.copyInto(vos); // 배열의 값을 복사해준다 - 이 메소드 쓰려고 굳이 벡터 쓴거얌
		} catch (SQLException se) {
			System.out.println("[[query]]" + sql.toString());
		} catch(Exception e) {
			e.printStackTrace(); // 에러 스택에 쌓여 있는 로그 정보 출력해줌. 라인번호도 같인
		} finally {
			// DB연동해서 사용한 자원 반납하기 - 노출가능, 우변조
			dbMgr.freeConnection(rs, pstmt, con);
		}
		return vos;
	}
}
}

/*
ID,NAME,ADDRESS,TELEPHONE,GENDER,RELATIONSHIP,BIRTHDAY,COMMENTS,REGISTEDATE
3,나초보,서울시 마포구 공덕동,025556968,2,2,19801215,주연테크,REGISTEDATE
1,홍길동,서울시 영등포구 당산동,111,1,동창,19901010,222,20081117
2,이순신,서울시 서초구 양재동,222,2,회사동료,19901110,333,20100113
4,강감찬,경기도 광명시,11,1,동창,19801120,테스트합니다.,2011-03-20
9,나초조,4455,44455,1,44555,19800702,자영업,20110320
7,223,223,223,2,223,223,223,20190609
10,조조,경기도 화성시,44455,1,44555,19800702,자영업,20110320
*/